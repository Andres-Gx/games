const palabras = [
    { palabra: 'pescado', pista: 'Animal acuático' },
    { palabra: 'elefante', pista: 'El animal terrestre más grande' },
    { palabra: 'pelota', pista: 'Se usa en muchos deportes' },
    { palabra: 'tomate', pista: 'Verdura roja que se usa en ensaladas' },
    { palabra: 'camisa', pista: 'Prenda de vestir' },
    { palabra: 'conejo', pista: 'Animal que salta mucho' },
    { palabra: 'papá', pista: 'Un miembro de la familia' },
    { palabra: 'manzana', pista: 'Fruta roja o verde' },
    { palabra: 'lobo', pista: 'Animal parecido a un perro, pero salvaje' }
];

let palabraSecreta = '';
let pistaSecreta = '';
let intentosRestantes = 6;
let letrasAdivinadas = [];
let letrasIncorrectas = [];
const partesCuerpo = ['cabeza', 'cuerpo', 'brazo-izquierdo', 'brazo-derecho', 'pierna-izquierda', 'pierna-derecha'];


function mostrarJuego() {
    document.getElementById('inicio').style.display = 'none'; 
    document.getElementById('juego').style.display = 'block'; 
    iniciarJuego(); 
}


function mostrarPalabra() {
    const palabraMostrada = palabraSecreta.split('').map(letra => (letrasAdivinadas.includes(letra) ? letra : '_')).join(' ');
    const palabraElemento = document.getElementById('palabra-secreta');
    palabraElemento.textContent = palabraMostrada;

 
    palabraElemento.classList.add('correcto');
    setTimeout(() => palabraElemento.classList.remove('correcto'), 300); 
}


function mostrarPista() {
    const pistaElemento = document.getElementById('pista');
    pistaElemento.textContent = `Pista: ${pistaSecreta}`;
}


function actualizarIntentos() {
    const intentosElemento = document.getElementById('intentos');
    intentosElemento.textContent = intentosRestantes;

   
    if (intentosRestantes < 6) {
        intentosElemento.classList.add('fallido');
        setTimeout(() => intentosElemento.classList.remove('fallido'), 1000);

        mostrarParteCuerpo(intentosRestantes);
    }
}


function mostrarParteCuerpo(intentosRestantes) {
    const parteCuerpo = document.querySelector(`.${partesCuerpo[6 - intentosRestantes]}`);
    if (parteCuerpo) {
        parteCuerpo.classList.remove('oculto');
    }
}

function actualizarLetrasIncorrectas() {
    document.getElementById('letras-incorrectas').textContent = `Letras incorrectas: ${letrasIncorrectas.join(', ')}`;
}


function verificarFinJuego() {
    const palabraMostrada = document.getElementById('palabra-secreta').textContent.replace(/\s+/g, '');
    const mensaje = document.getElementById('mensaje');

    if (palabraMostrada === palabraSecreta) {
        mensaje.textContent = '¡Felicidades! Has adivinado la palabra.';
        deshabilitarEntrada();
    } else if (intentosRestantes <= 0) {
        mensaje.textContent = `¡Perdiste! La palabra era: ${palabraSecreta}`;
        deshabilitarEntrada();
    }
}


function deshabilitarEntrada() {
    document.getElementById('letra').disabled = true;
    document.getElementById('adivinar-btn').disabled = true;
}


function adivinar() {
    const inputLetra = document.getElementById('letra');
    const letra = inputLetra.value.toLowerCase();

    if (letra && letra.length === 1 && /^[a-z]$/.test(letra)) {
        if (palabraSecreta.includes(letra)) {
            if (!letrasAdivinadas.includes(letra)) {
                letrasAdivinadas.push(letra);
                mostrarPalabra();
            }
        } else {
            if (!letrasIncorrectas.includes(letra)) {
                letrasIncorrectas.push(letra);
                intentosRestantes--;
                actualizarIntentos();
                actualizarLetrasIncorrectas();
            }
        }
    } else {
        alert('Por favor, ingresa una letra válida.');
    }

    inputLetra.value = '';
    verificarFinJuego();
}


function iniciarJuego() {
    const seleccion = palabras[Math.floor(Math.random() * palabras.length)];
    palabraSecreta = seleccion.palabra;
    pistaSecreta = seleccion.pista;

    intentosRestantes = 6;
    letrasAdivinadas = [];
    letrasIncorrectas = [];

    partesCuerpo.forEach(parte => {
        document.querySelector(`.${parte}`).classList.add('oculto');
    });

    document.getElementById('mensaje').textContent = '';
    document.getElementById('letra').disabled = false;
    document.getElementById('adivinar-btn').disabled = false;
    document.getElementById('reiniciar-btn').disabled = false;

    mostrarPalabra();
    mostrarPista();
    actualizarIntentos();
    actualizarLetrasIncorrectas();
}


function reiniciarJuego() {
    iniciarJuego();
}
