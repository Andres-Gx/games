let numeroAleatorio = Math.floor(Math.random() * 100) + 1; 
let intentosRestantes = 10; 

const inputNumero = document.getElementById('userGuess');
const botonAdivinar = document.getElementById('submitGuess');
const mensajeResultado = document.getElementById('message');
const intentosTexto = document.getElementById('remainingGuesses');
const botonReiniciar = document.getElementById('restartGame');


intentosTexto.textContent = `Intentos restantes: ${intentosRestantes}`;


botonAdivinar.addEventListener('click', () => {
    const numeroUsuario = parseInt(inputNumero.value);
    

    if (isNaN(numeroUsuario) || numeroUsuario < 1 || numeroUsuario > 100) {
        mensajeResultado.textContent = "Por favor, introduce un número válido entre 1 y 100.";
        mensajeResultado.style.color = "black";
        return;
    }

    intentosRestantes--; 
    intentosTexto.textContent = `Intentos restantes: ${intentosRestantes}`;

    
    const distancia = Math.abs(numeroAleatorio - numeroUsuario);
    let colorFondo;

    if (numeroUsuario === numeroAleatorio) {
        
        mensajeResultado.textContent = `¡Felicidades! Adivinaste el número correcto: ${numeroAleatorio}`;
        mensajeResultado.style.color = "green";
        document.body.style.backgroundColor = "#8BC34A"; 
        botonAdivinar.disabled = true; 
    } else {
        
        if (numeroUsuario < numeroAleatorio) {
            mensajeResultado.textContent = "El número es más grande.";
        } else {
            mensajeResultado.textContent = "El número es más pequeño.";
        }

        
        if (distancia <= 10) {
            mensajeResultado.style.color = "#59C659"; 
            colorFondo = `rgb(144, 238, 144)`; 
        } else if (distancia <= 30) {
            mensajeResultado.style.color = "#7DD100";
            colorFondo = `rgb(173, 255, 47)`; 
        } else if (distancia <= 50) {
            mensajeResultado.style.color = "#FFBD37";
            colorFondo = `rgb(255, 165, 0)`; 
        } else {
            mensajeResultado.style.color = "#FF2B00           ";
            colorFondo = `rgb(255, 99, 71)`; 
        }
        document.body.style.backgroundColor = colorFondo; 
    }

    
    if (intentosRestantes === 0 && numeroUsuario !== numeroAleatorio) {
        mensajeResultado.textContent = `¡Game Over! El número era: ${numeroAleatorio}`;
        mensajeResultado.style.color = "red";
        document.body.style.backgroundColor = "#FF6347"; 
        botonAdivinar.disabled = true; 
    }
});

botonReiniciar.addEventListener('click', reiniciarJuego);

function reiniciarJuego() {
    numeroAleatorio = Math.floor(Math.random() * 100) + 1; 
    intentosRestantes = 10; 
    botonAdivinar.disabled = false; 
    mensajeResultado.textContent = ''; 
    intentosTexto.textContent = `Intentos restantes: ${intentosRestantes}`;
    inputNumero.value = ''; 
    document.body.style.backgroundColor = "#FFFFFF"; 
}
