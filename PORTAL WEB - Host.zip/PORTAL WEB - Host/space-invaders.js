const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
canvas.width = 600;
canvas.height = 400;

let gameInterval;
let keys = {};
let enemyBullets = [];
let lastEnemyShotTime = 0;
let playerShotCooldown = 500; 
let lastPlayerShot = 0;

const player = {
  x: canvas.width / 2 - 15,
  y: canvas.height - 50,
  width: 30,
  height: 30,
  speed: 5,
  lives: 3,
  bullets: [],
  score: 0,
};

let enemies = [];
let enemyDirection = 1;

function createEnemies() {
  enemies = [];
  for (let row = 0; row < 4; row++) {
    for (let col = 0; col < 8; col++) {
      enemies.push({
        x: col * 60 + 20,
        y: row * 40 + 20,
        width: 30,
        height: 30,
        alive: true,
      });
    }
  }
}

function update() {
  if (keys['ArrowLeft'] && player.x > 0) player.x -= player.speed;
  if (keys['ArrowRight'] && player.x + player.width < canvas.width) player.x += player.speed;


  if (keys[' '] && Date.now() - lastPlayerShot > playerShotCooldown) {
    shootPlayerBullet();
    lastPlayerShot = Date.now();
  }

  player.bullets.forEach((bullet, index) => {
    bullet.y -= 7;
    if (bullet.y < 0) player.bullets.splice(index, 1);
  });


  if (Date.now() - lastEnemyShotTime > 1000) {
    shootEnemyBullet();
    lastEnemyShotTime = Date.now();
  }

  enemyBullets.forEach((bullet, index) => {
    bullet.y += 5;
    if (bullet.y > canvas.height) enemyBullets.splice(index, 1);
    if (checkCollision(bullet, player)) {
      enemyBullets.splice(index, 1);
      player.lives--;
      if (player.lives === 0) endGame(false);
    }
  });

  moveEnemies();
  detectCollisions();
  draw();
}

function shootPlayerBullet() {
  player.bullets.push({
    x: player.x + player.width / 2 - 2.5,
    y: player.y,
    width: 5,
    height: 10,
  });
}

function shootEnemyBullet() {
  const aliveEnemies = enemies.filter((enemy) => enemy.alive);
  if (aliveEnemies.length === 0) return;

  const shooter = aliveEnemies[Math.floor(Math.random() * aliveEnemies.length)];
  enemyBullets.push({
    x: shooter.x + shooter.width / 2 - 2.5,
    y: shooter.y + shooter.height,
    width: 5,
    height: 10,
  });
}

function moveEnemies() {
  let edgeReached = false;
  enemies.forEach((enemy) => {
    if (enemy.alive) {
      enemy.x += enemyDirection * 2;
      if (enemy.x + enemy.width > canvas.width || enemy.x < 0) {
        edgeReached = true;
      }
    }
  });

  if (edgeReached) {
    enemyDirection *= -1;
    enemies.forEach((enemy) => (enemy.y += 10));
  }
}

function detectCollisions() {
  enemies.forEach((enemy) => {
    if (!enemy.alive) return;
    player.bullets.forEach((bullet, index) => {
      if (checkCollision(bullet, enemy)) {
        enemy.alive = false;
        player.score += 100;
        player.bullets.splice(index, 1);
      }
    });
  });

  if (enemies.every((enemy) => !enemy.alive)) endGame(true);
}

function checkCollision(rect1, rect2) {
  return (
    rect1.x < rect2.x + rect2.width &&
    rect1.x + rect1.width > rect2.x &&
    rect1.y < rect2.y + rect2.height &&
    rect1.y + rect1.height > rect2.y
  );
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  ctx.fillStyle = 'white';
  ctx.fillRect(player.x, player.y, player.width, player.height);

  player.bullets.forEach((bullet) =>
    ctx.fillRect(bullet.x, bullet.y, bullet.width, bullet.height)
  );

  enemyBullets.forEach((bullet) =>
    ctx.fillRect(bullet.x, bullet.y, bullet.width, bullet.height)
  );

  enemies.forEach((enemy) => {
    if (enemy.alive) {
      ctx.fillStyle = 'red';
      ctx.fillRect(enemy.x, enemy.y, enemy.width, enemy.height);
    }
  });

  ctx.fillStyle = 'white';
  ctx.fillText(`Vidas: ${player.lives}`, 10, 20);
  ctx.fillText(`Puntuación: ${player.score}`, canvas.width - 150, 20);
}

function endGame(victory) {
  clearInterval(gameInterval);
  document.getElementById('gameOverMessage').textContent = victory ? '¡Victoria!' : 'Game Over';
  document.getElementById('finalScore').textContent = player.score;
  document.getElementById('gameOverScreen').classList.remove('hidden');
}

document.getElementById('startButton').addEventListener('click', () => {
  document.getElementById('startScreen').classList.add('hidden');
  startGame();
});

document.getElementById('restartButton').addEventListener('click', () => {
  document.getElementById('gameOverScreen').classList.add('hidden');
  startGame();
});

function startGame() {
  player.lives = 3;
  player.score = 0;
  createEnemies();
  gameInterval = setInterval(update, 1000 / 60);
}

window.addEventListener('keydown', (e) => (keys[e.key] = true));
window.addEventListener('keyup', (e) => (keys[e.key] = false));
