const puzzle = document.getElementById("puzzle");
const moveCounter = document.getElementById("moveCounter");
let tiles = [];
let emptyIndex = 15;
let moves = 0;


function initPuzzle() {
    tiles = [...Array(15).keys()].map(i => i + 1).concat(null);
    renderPuzzle();
}


function renderPuzzle() {
    puzzle.innerHTML = "";
    tiles.forEach((value, index) => {
        const tile = document.createElement("div");
        tile.classList.add("tile");
        if (value) {
            tile.textContent = value;
            tile.addEventListener("click", () => moveTile(index));
        } else {
            tile.classList.add("empty");
            emptyIndex = index;
        }
        puzzle.appendChild(tile);
    });
}


function shuffleTiles() {
    do {
        for (let i = tiles.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [tiles[i], tiles[j]] = [tiles[j], tiles[i]];
        }
    } while (!isSolvable() || isSolved()); 

    moves = 0;
    moveCounter.textContent = moves;
    renderPuzzle();
}


function isSolvable() {
    let inversions = 0;
    const flatTiles = tiles.filter(n => n !== null);

    for (let i = 0; i < flatTiles.length; i++) {
        for (let j = i + 1; j < flatTiles.length; j++) {
            if (flatTiles[i] > flatTiles[j]) inversions++;
        }
    }

    const rowFromBottom = Math.floor(emptyIndex / 4) + 1;
    return (inversions % 2 === 0) === (rowFromBottom % 2 !== 0);
}


function moveTile(index) {
    const validMoves = [emptyIndex - 1, emptyIndex + 1, emptyIndex - 4, emptyIndex + 4];

    if (validMoves.includes(index)) {
        [tiles[emptyIndex], tiles[index]] = [tiles[index], tiles[emptyIndex]];
        emptyIndex = index;
        moves++;
        moveCounter.textContent = moves;
        renderPuzzle();
        checkWin();
    }
}


function isSolved() {
    return tiles.slice(0, 15).every((value, index) => value === index + 1);
}


function checkWin() {
    if (isSolved()) {
        setTimeout(() => alert(`Congratulations! You solved it in ${moves} moves.`), 100);
    }
}


window.onload = initPuzzle;
