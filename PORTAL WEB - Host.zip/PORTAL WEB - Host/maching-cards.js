const gameBoard = document.getElementById('gameBoard');
const scoreDisplay = document.getElementById('score');
const timerDisplay = document.getElementById('timer');
const attemptsDisplay = document.getElementById('attempts');
const restartBtn = document.getElementById('restartBtn');
const startBtn = document.getElementById('startBtn');

let cards = [];
let flippedCards = [];
let score = 0;
let attempts = 0;
let timer;
let timeElapsed = 0;
let gameStarted = false;

const pairColors = ['#e74c3c', '#f39c12', '#27ae60', '#2980b9', '#8e44ad', '#3498db', '#9b59b6', '#1abc9c'];
let colorIndex = 0;

function initializeGame() {
    cards = createCardArray();
    renderCards();
    resetGameStats();
}

function createCardArray() {
    const cardValues = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];
    const cardArray = [...cardValues, ...cardValues];
    return cardArray.sort(() => Math.random() - 0.5);
}

function renderCards() {
    gameBoard.innerHTML = '';
    cards.forEach((value, index) => {
        const card = document.createElement('div');
        card.classList.add('card');
        card.setAttribute('data-value', value);
        card.setAttribute('data-index', index);
        card.style.backgroundColor = '#3498db'; 
        card.addEventListener('click', flipCard);
        gameBoard.appendChild(card);
    });
}

function flipCard() {
    if (flippedCards.length < 2 && !this.classList.contains('flipped') && !this.classList.contains('matched')) {
        this.classList.add('flipped');
        this.textContent = this.getAttribute('data-value');
        flippedCards.push(this);

        if (flippedCards.length === 2) {
            checkForMatch();
        }
    }
}

function checkForMatch() {
    attempts++;
    attemptsDisplay.textContent = `Intentos: ${attempts}`;
    
    const [firstCard, secondCard] = flippedCards;
    if (firstCard.getAttribute('data-value') === secondCard.getAttribute('data-value')) {
        score++;
        scoreDisplay.textContent = `Aciertos: ${score}`;
        
        const color = pairColors[colorIndex++];
        firstCard.classList.add('matched');
        secondCard.classList.add('matched');
        firstCard.style.backgroundColor = color;
        secondCard.style.backgroundColor = color; 
    } else {
        setTimeout(() => {
            firstCard.classList.remove('flipped');
            secondCard.classList.remove('flipped');
            firstCard.textContent = '';
            secondCard.textContent = '';
        }, 1000);
    }
    flippedCards = [];

    if (score === cards.length / 2) {
        clearInterval(timer);
        alert(`¡Juego terminado! Aciertos: ${score}, Intentos: ${attempts}, Tiempo: ${timeElapsed}s`);
    }
}

function resetGameStats() {
    score = 0;
    attempts = 0;
    timeElapsed = 0;
    scoreDisplay.textContent = `Aciertos: 0`;
    attemptsDisplay.textContent = `Intentos: 0`;
    timerDisplay.textContent = `Tiempo: 0s`;
}

function startTimer() {
    timer = setInterval(() => {
        timeElapsed++;
        timerDisplay.textContent = `Tiempo: ${timeElapsed}s`;
    }, 1000);
}

startBtn.addEventListener('click', () => {
    if (!gameStarted) {
        gameStarted = true;
        initializeGame();
        startTimer();
        startBtn.style.display = 'none';
        restartBtn.style.display = 'inline';
    }
});

restartBtn.addEventListener('click', () => {
    clearInterval(timer);
    gameStarted = false;
    resetGameStats();
    colorIndex = 0; 
    startBtn.style.display = 'inline';
    restartBtn.style.display = 'none';
});
