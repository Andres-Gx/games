
        function jugar(eleccionJugador) {
            const opciones = ['piedra', 'papel', 'tijera'];
            const eleccionComputadora = opciones[Math.floor(Math.random() * 3)];

            const resultado = determinarGanador(eleccionJugador, eleccionComputadora);

            document.getElementById("resultado").innerHTML = `
                Tú elegiste: ${eleccionJugador}<br>
                La computadora eligió: ${eleccionComputadora}<br>
                Resultado: ${resultado}
            `;
        }

        function determinarGanador(jugador, computadora) {
            if (jugador === computadora) {
                return "¡Es un empate!";
            }

            if ((jugador === 'piedra' && computadora === 'tijera') ||
                (jugador === 'papel' && computadora === 'piedra') ||
                (jugador === 'tijera' && computadora === 'papel')) {
                return "¡Ganaste!";
            } else {
                return "La computadora gana.";
            }
        }
    