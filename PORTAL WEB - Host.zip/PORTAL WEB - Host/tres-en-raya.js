let tablero = Array(9).fill(null);
let jugadorActual = 'X'; 
let juegoTerminado = false;

const casillas = document.querySelectorAll('.casilla');
const mensaje = document.getElementById('mensaje');
const botonReiniciar = document.getElementById('reiniciar');

const combinacionesGanadoras = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8],  
    [0, 3, 6], [1, 4, 7], [2, 5, 8],  
    [0, 4, 8], [2, 4, 6]              
];

casillas.forEach(casilla => {
    casilla.addEventListener('click', () => {
        const index = casilla.getAttribute('data-index');


        if (tablero[index] !== null || juegoTerminado || jugadorActual !== 'X') return;


        realizarMovimiento(index, jugadorActual);


        if (verificarGanador()) {
            mensaje.textContent = `¡El jugador ${jugadorActual} ha ganado!`;
            juegoTerminado = true;
            return;
        }

      
        if (verificarEmpate()) {
            mensaje.textContent = "¡Es un empate!";
            juegoTerminado = true;
            return;
        }

       
        jugadorActual = 'O';
        mensaje.textContent = "Turno de la computadora...";

        setTimeout(() => {
            realizarMovimientoIA();
        }, 500); 
    });
});


function realizarMovimiento(index, jugador) {
    if (tablero[index] === null && !juegoTerminado) {
        tablero[index] = jugador;
        casillas[index].textContent = jugador;

        if (verificarGanador()) {
            mensaje.textContent = `¡El jugador ${jugador} ha ganado!`;
            juegoTerminado = true;
        } else if (verificarEmpate()) {
            mensaje.textContent = "¡Es un empate!";
            juegoTerminado = true;
        }
    }
}


function realizarMovimientoIA() {
    if (juegoTerminado) return;

  
    const indexIA = tablero.findIndex(casilla => casilla === null);
    realizarMovimiento(indexIA, 'O');


    if (!juegoTerminado) {
        jugadorActual = 'X';
        mensaje.textContent = `Turno del jugador ${jugadorActual}`;
    }
}


function verificarGanador() {
    return combinacionesGanadoras.some(combinacion => {
        const [a, b, c] = combinacion;
        return tablero[a] && tablero[a] === tablero[b] && tablero[a] === tablero[c];
    });
}


function verificarEmpate() {
    return tablero.every(casilla => casilla !== null);
}


botonReiniciar.addEventListener('click', () => {
    tablero = Array(9).fill(null);
    jugadorActual = 'X';
    juegoTerminado = false;
    mensaje.textContent = `Turno del jugador ${jugadorActual}`;
    casillas.forEach(casilla => casilla.textContent = '');
});